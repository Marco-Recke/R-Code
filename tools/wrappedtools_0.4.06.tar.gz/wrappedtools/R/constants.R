logrange_all <- seq(1,9.9,.1)*rep(10^(-20:20),each=90)
#'@export
logrange_5 <- seq(1,9.5,.5)*rep(10^(-20:20),each=18)
logrange_1_1_5_5 <- c(seq(1,5,.1),seq(5.5,9.5,.5))*rep(10^(-20:20),each=50)
logrange_evenlonger<-c(seq(1,1.9,.1),seq(2,8,.5),9)*rep(10^(-20:20),each=24)
#'@export
logrange_123456789<-c(1:9)*rep(10^(-20:20),each=9)
#'@export
logrange_12357<-c(1,2,3,5,7)*rep(10^(-20:20),each=5)
#'@export
logrange_15<-c(1,5)*rep(10^(-20:20),each=2)
#'@export
logrange_1<-c(1)*rep(10^(-20:20),each=1)
